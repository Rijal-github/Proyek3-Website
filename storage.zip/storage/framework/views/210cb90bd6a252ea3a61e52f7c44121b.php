<?php $__env->startSection('title','Checkout Penitipan page'); ?>

<?php $__env->startSection('main-content'); ?>

    <!-- Breadcrumbs -->
    <div class="breadcrumbs">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="bread-inner">
                        <ul class="bread-list">
                            <li><a href="<?php echo e(route('home')); ?>">Home<i class="ti-arrow-right"></i></a></li>
                            <li class="active"><a href="javascript:void(0)">Checkout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumbs -->
            
    <!-- Start Checkout -->
    <section class="shop checkout section">
        <div class="container">
                <form class="form" method="POST" action="<?php echo e(route('cart.penitipan')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row"> 

                        <div class="col-lg-8 col-12">
                            <div class="checkout-form">
                                <h2>Lakukan Pembayaran Anda Di Sini</h2>
                                <p>Silakan mendaftar untuk melakukan penitipan</p>
                                <!-- Form -->
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Nama depan<span>*</span></label>
                                            <input type="text" name="nama_depan" placeholder="" value="<?php echo e(old('nama_depan')); ?>" value="<?php echo e(old('nama_depan')); ?>">
                                            <?php $__errorArgs = ['nama_depan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class='text-danger'><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Nama belakang<span>*</span></label>
                                            <input type="text" name="nama_belakang" placeholder="" value="<?php echo e(old('lat_name')); ?>">
                                            <?php $__errorArgs = ['nama_belakang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class='text-danger'><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Email Anda<span>*</span></label>
                                            <input type="email" name="email" placeholder="" value="<?php echo e(old('email')); ?>">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class='text-danger'><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="form-group">
                                            <label>No Telephone <span>*</span></label>
                                            <input type="number" name="phone" placeholder="" required value="<?php echo e(old('phone')); ?>">
                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class='text-danger'><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Address Line 1</label>
                                            <input type="text" name="address1" placeholder="" value="<?php echo e(old('address1')); ?>">
                                            <?php $__errorArgs = ['address1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class='text-danger'><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Kode Pos</label>
                                            <input type="text" name="post_code" placeholder="" value="<?php echo e(old('post_code')); ?>">
                                            <?php $__errorArgs = ['post_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class='text-danger'><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Catatan untuk Penitipan</label>
                                            <textarea class="form-control" id="description" name="description"><?php echo e(old('description')); ?></textarea>
                                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class='text-danger'><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    
                                    
                                </div>
                                <!--/ End Form -->
                            </div>
                        </div>
                        <div class="col-lg-4 col-12">
                            <div class="order-details">
                                <!-- Order Widget -->
                                <div class="single-widget">
                                    <h2>CART  TOTALS</h2>
                                    <div class="content">
                                        <ul>
										    <li class="order_subtotal" data-price="<?php echo e(Helper::totalCartPrice()); ?>">Cart Subtotal<span>Rp.<?php echo e(number_format(Helper::totalCartPrice(),2)); ?></span></li>
                                            <li class="shipping">
                                                Shipping Cost
                                                <?php if(count(Helper::shipping())>0 && Helper::cartCount()>0): ?>
                                                    <select name="shipping" class="nice-select">
                                                        <option value="">Select your address</option>
                                                        <?php $__currentLoopData = Helper::shipping(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($shipping->id); ?>" class="shippingOption" data-price="<?php echo e($shipping->price); ?>"><?php echo e($shipping->type); ?>: Rp.<?php echo e($shipping->price); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                <?php else: ?> 
                                                    <span>Free</span>
                                                <?php endif; ?>
                                            </li>
                                            <li class="penitipan">
                                                Harga Penitipan
                                                <?php if(count(Helper::hargapenitipan())>0 && Helper::cartCount()>0): ?>
                                                <div class="form-group">                                                                                              
                                                    <input type="number" class="nice-select" name="angka" placeholder="Berapa jangka waktu" required value="<?php echo e(old('angka')); ?>">
                                                </div>
                                                    <select name="hargapenitipan" class="nice-select">
                                                        <option value="">pilih harian,bulanan</option>
                                                        <?php $__currentLoopData = Helper::hargapenitipan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hargapenitipan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($hargapenitipan->id); ?>" class="hargapenitipanOption" data-price="<?php echo e($hargapenitipan->price); ?>"><?php echo e($hargapenitipan->waktu); ?>: Rp.<?php echo e($hargapenitipan->price); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                <?php else: ?> 
                                                    <span>Free</span>
                                                <?php endif; ?>
                                            </li>
                                            
                                            <?php if(session('coupon')): ?>
                                            <li class="coupon_price" data-price="<?php echo e(session('coupon')['value']); ?>">You Save<span>Rp.<?php echo e(number_format(session('coupon')['value'],2)); ?></span></li>
                                            <?php endif; ?>
                                            <?php
                                                $total_amount=Helper::totalCartPrice();
                                                if(session('coupon')){
                                                    $total_amount=$total_amount-session('coupon')['value'];
                                                }
                                            ?>
                                            <?php if(session('coupon')): ?>
                                                <li class="last"  id="order_total_price">Total<span>Rp.<?php echo e(number_format($total_amount,2)); ?></span></li>
                                            <?php else: ?>
                                                <li class="last"  id="order_total_price">Total<span>Rp.<?php echo e(number_format($total_amount,2)); ?></span></li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </div>
                                <!--/ End Order Widget -->
                                <!-- Order Widget -->
                                <div class="single-widget">
                                    <h2>Payments</h2>
                                    <div class="content">
                                        <div class="checkbox">
                                            
                                            <form-group>
                                                <input name="payment_method"  type="radio" value="cod"> <label> Cash On Delivery</label><br>
                                                <input name="payment_method"  type="radio" value="paypal"> <label> Dana</label> 
                                            </form-group>
                                            
                                        </div>
                                    </div>
                                </div>
                                <!--/ End Order Widget -->
                                <!-- Payment Method Widget -->
                                <div class="single-widget payement">
                                    <div class="content">
                                        <img src="<?php echo e(('backend/img/payment-method.png')); ?>" alt="#">
                                    </div>
                                </div>
                                <!--/ End Payment Method Widget -->
                                <!-- Button Widget -->
                                <div class="single-widget get-button">
                                    <div class="content">
                                        <div class="button">
                                            <button type="submit" class="btn">Proses ke Penitipan</button>
                                        </div>
                                    </div>
                                </div>
                                <!--/ End Button Widget -->
                            </div>
                        </div>
                    </div>
                </form>
        </div>
    </section>
    <!--/ End Checkout -->
    
    <!-- Start Shop Services Area  -->
    <section class="shop-services section home">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Start Single Service -->
                    <div class="single-service">
                        <i class="ti-rocket"></i>
                        <h4>Free shiping</h4>
                        <p>Orders over $100</p>
                    </div>
                    <!-- End Single Service -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Start Single Service -->
                    <div class="single-service">
                        <i class="ti-reload"></i>
                        <h4>Free Return</h4>
                        <p>Within 30 days returns</p>
                    </div>
                    <!-- End Single Service -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Start Single Service -->
                    <div class="single-service">
                        <i class="ti-lock"></i>
                        <h4>Sucure Payment</h4>
                        <p>100% secure payment</p>
                    </div>
                    <!-- End Single Service -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Start Single Service -->
                    <div class="single-service">
                        <i class="ti-tag"></i>
                        <h4>Best Peice</h4>
                        <p>Guaranteed price</p>
                    </div>
                    <!-- End Single Service -->
                </div>
            </div>
        </div>
    </section>
    <!-- End Shop Services -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
	<style>
		li.shipping{
			display: inline-flex;
			width: 100%;
			font-size: 14px;
		}
		li.shipping .input-group-icon {
			width: 100%;
			margin-left: 10px;
		}
        li.penitipan{
			display: inline-flex;
			width: 100%;
			font-size: 14px;
		}
		li.penitipan .input-group-icon {
			width: 100%;
			margin-left: 10px;
		}
		.input-group-icon .icon {
			position: absolute;
			left: 20px;
			top: 0;
			line-height: 40px;
			z-index: 3;
		}
		.form-select {
			height: 30px;
			width: 100%;
		}
		.form-select .nice-select {
			border: none;
			border-radius: 0px;
			height: 40px;
			background: #f6f6f6 !important;
			padding-left: 45px;
			padding-right: 40px;
			width: 100%;
		}
		.list li{
			margin-bottom:0 !important;
		}
		.list li:hover{
			background:#F7941D !important;
			color:white !important;
		}
		.form-select .nice-select::after {
			top: 14px;
		}
	</style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
	<script src="<?php echo e(asset('frontend/js/nice-select/js/jquery.nice-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/select2/js/select2.min.js')); ?>"></script>
	<script>
		$(document).ready(function() { $("select.select2").select2(); });
  		$('select.nice-select').niceSelect();
	</script>
	<script>
		function showMe(box){
			var checkbox=document.getElementById('shipping').style.display;
            var checkbox=document.getElementById('penitipan').style.display;
			// alert(checkbox);
			var vis= 'none';
			if(checkbox=="none"){
				vis='block';
			}
			if(checkbox=="block"){
				vis="none";
			}
			document.getElementById(box).style.display=vis;
		}
	</script>
	<script>
		$(document).ready(function(){
            $('select[name=shipping], select[name=hargapenitipan], input[name=angka]').change(function(){
                // Ambil nilai biaya pengiriman dari elemen terpilih di select[name=shipping]
                let shippingCost = parseFloat($('select[name=shipping] option:selected').data('price')) || 0;

                // Ambil nilai biaya dari elemen terpilih di select[name=other_select]
                let otherCost = parseFloat($('select[name=hargapenitipan] option:selected').data('price')) || 0;

                let subtotal = parseFloat($('.order_subtotal').data('price')); 
                let coupon = parseFloat($('.coupon_price').data('price')) || 0;

                // Ambil nilai dari elemen input[name=angka]
                let angkaValue = parseFloat($('input[name=angka]').val()) || 0;

                // Jumlahkan biaya pengiriman, biaya dari other_select, subtotal, nilai angka, dan kurangkan coupon
                let total = subtotal + shippingCost + (otherCost*angkaValue) - coupon;

                // Tampilkan hasilnya di elemen dengan ID 'order_total_price'
                $('#order_total_price span').text('$' + total.toFixed(2));
            });
});


	</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\proyek2\Template\Complete-Ecommerce-in-laravel-10-master\resources\views/frontend/pages/checkoutpenitipan.blade.php ENDPATH**/ ?>